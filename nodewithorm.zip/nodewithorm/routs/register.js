const express = require('express');
const router = express.Router();

const db = require('../database/config');
const user = require('../models/user');

router.post('/', (req, res) =>

    user.create(
       req.body
    )
    .then((user) => res.json(
            {
                "sucess": "true",
                "message": "Successfully registered.."

            }
        ))
        .catch(err => res.json(err))
);

module.exports = router;