const express = require('express');
const router = express.Router();

const db = require('../database/config');
const User = require('../models/user');

router.post('/', function (req, res) {
    User.findOne(
        {
            where: {
                email: req.body.email,
                password: req.body.password
            }
        }
    ).then(user => {
        if (!user) {
            return res.json(
                {
                    "message": "Failed to login"
                }
            )
        } else {
             return res.json(
                {
                    "message": "Login Successfully done"
                }
            )
        }
    })

});
module.exports = router;