const express=require('express');
const router=express.Router();

const db=require('../database/config');
const User=require('../models/user');
//const User=require('../models/User');

router.get('/',(req,res)=>
    res.json(
        {
            "success":true
        }
    ));

module.exports=router;